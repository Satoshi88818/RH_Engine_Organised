# Documentation

These Markdown files are cleaned and lightly reformatted versions of the original research notes.

| Document | Original source | Topic |
|----------|-----------------|-------|
| [assessment.md](assessment.md) | RH_Assessment.txt | Critical review of the earlier variational / “Dynamic Spectral Magnetic Field” approach |
| [energy.md](energy.md) | RH_ENERGY.txt | Candidate energy functional \(E(\sigma)\) |
| [harness.md](harness.md) | Empirical_Harness_Local_Collision.txt | Gap-lifetime lemma and empirical collision times |
| [lifetime_scaling.md](lifetime_scaling.md) | RH_Lifetime_Scaling.txt | Scaling of closest-pair lifetimes with height |
| [function_field.md](function_field.md) | RH_Function_Field_Analogue.txt | Function-field analogues and Bogomolny–Keating formula |
| [forward_flow.md](forward_flow.md) | RH_Forward_Flow.txt | Forward heat flow (\(t>0\)) and winding-number tests |

Many additional experimental notes (Li criterion, Dirichlet L-functions, primes-and-repulsion statistics, Riemann–Siegel evaluator details, etc.) remain in the original repository as flat `.txt` files. They can be migrated into this tree as needed.
